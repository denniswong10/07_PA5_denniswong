﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed;
    private Rigidbody thisRigibody = null;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Coins")
        {
            GameManager.score++;
            Destroy(other.gameObject);
        }

        if (other.tag == "Obstacle")
        {
            GameManager.Hazards = true;
        }
    }

    void movement()
    {
        float moveHortizonal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHortizonal, 0, moveVertical);
        thisRigibody.AddForce(movement * speed * Time.deltaTime);
    }

    // Start is called before the first frame update
    void Start()
    {
        thisRigibody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        movement();
    }
}

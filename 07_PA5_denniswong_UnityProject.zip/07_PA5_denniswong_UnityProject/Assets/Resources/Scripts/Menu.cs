﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public void option_select(int menu)
    {
        GameManager.Hazards = false;

        switch (menu)
        {
            case 1:
                SceneManager.LoadScene("Level" + GameManager.level);
                break;

            case 2:
                GameManager.level++;
                SceneManager.LoadScene("Level" + GameManager.level);
                break;
        }
    }

    public void startMenu()
    {
        SceneManager.LoadScene("Level1");
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public Transform Player;

    public float smoothSpeed = 0.1f;
    private Vector3 offset = new Vector3(0, 3, -4);

    void FixedUpdate()
    {
        Vector3 desirePosition = Player.position + offset;
        Vector3 smoothPosition = Vector3.Lerp(transform.position, desirePosition, smoothSpeed);
        transform.position = smoothPosition;

        transform.LookAt(Player);
    }
}

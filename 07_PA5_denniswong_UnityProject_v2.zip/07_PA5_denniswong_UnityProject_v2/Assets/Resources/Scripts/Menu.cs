﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public int maxLevel;

    public void option_select(int menu)
    {
        GameManager.Hazards = false;

        switch (menu)
        {
            case 1:
                SceneManager.LoadScene("Level" + GameManager.level);
                break;

            case 2:
             

                if (GameManager.level < maxLevel)
                {
                    GameManager.level++;
                    SceneManager.LoadScene("Level" + GameManager.level);
                }
                else
                    SceneManager.LoadScene("StartScreen");
                break;
        }
    }

    public void startMenu()
    {
        SceneManager.LoadScene("Level1");
    }
}

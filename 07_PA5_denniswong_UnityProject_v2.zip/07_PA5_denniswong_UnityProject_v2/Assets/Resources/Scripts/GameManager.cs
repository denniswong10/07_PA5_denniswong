﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public interface IGameManager
{
    // Update Status
    void Update_GameInterface();

    // Update Condition
    void Update_GameCondition();
}

public class GameManager : MonoBehaviour, IGameManager
{
    public static int score = 0;
    private int base_score = 0;
    public static int level = 0;
    public static bool Hazards = false;

    public GameObject GameInterface;

    public void Update_GameInterface()
    {
        GameInterface.transform.GetChild(0).GetComponent<Text>().text = "Star Collected : " + score + " / " + base_score;
    }

    public void Update_GameCondition()
    {
        if (score.Equals(base_score))
            SceneManager.LoadScene("WinScreen");

        if (Hazards)
            SceneManager.LoadScene("LoseScreen");
    }

    // Start is called before the first frame update
    void Start()
    {
        if (SceneManager.GetActiveScene().name == "Level1")
            level = 1;

        score = 0;
        base_score = GameObject.FindGameObjectsWithTag("Coins").Length;
    }

    // Update is called once per frame
    void Update()
    {
        Update_GameInterface();
        Update_GameCondition();
    }
}
